# Tests proper sorting of modules in yacc.ParserReflect.get_pfunctions

# Here for testing purposes
import sys
if '..' not in sys.path:
    sys.path.insert(0, '..')

from .parsing.calcparse import parser

